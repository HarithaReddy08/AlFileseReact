import React from 'react';

function Home(props) {
    return (

        <div class="jumbotron">
            <h1 class="display-3">Awesome Store</h1>
            <p class="lead">More thsn 2 crore Products</p>
            <hr class="my-2"/>
            <p>welcome to Gatlas Awesome store . There is not a thing in the whole world find here</p>
            <p class="lead">
                <a class="btn btn-primary btn-lg" href="/catalog" role="button">check catalog</a>
            </p>
        </div>
    
    );
}

export default Home;
import { createStore, combineReducers } from 'redux';
import products from './reducers/products';


export default createStore( 
    // use combineReducers() to generate a master reducer tha that delegates to counter and form reducers
    combineReducers(
        {
            productState: products,
          
        }
    )
);
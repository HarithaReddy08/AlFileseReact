// action types
const INCREMENT = 'INCREMENT';
const DECREMENT = 'DECREMENT';
const UPDATE_NAME= 'UPDATE_NAME';
// add constant UPDATE_NAME and export

export {
    INCREMENT,
    DECREMENT,
    UPDATE_NAME
};
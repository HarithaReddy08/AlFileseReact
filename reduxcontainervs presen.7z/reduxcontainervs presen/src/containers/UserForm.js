// Use connect() to define the connected component (aka container component) for UserForm. Define mapDispatchToProps() and mapStateToProps() to be passed to connect().
import {connect} from 'react-redux';
import UserForm from '../components/UserForm';
import { updateNameAC } from '../actions/creators';

const mapStateToProps=(state)=>{
    return{
        name:state.formState.name
    }
}
const mapDispatchToProps=(dispatch)=>
{
    return{
    updateName(name)
    {
dispatch(updateNameAC(name));
    }
  
}
}
export default connect(mapStateToProps,mapDispatchToProps)(UserForm);
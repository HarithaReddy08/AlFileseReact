//rcc
import React, { Component } from 'react';

import Alert from '../components/Alert';

import {Link } from 'react-router-dom';

import CatalogService from '../Services/Catalog';
const REVIEWS_FETCHING='REVIEWS_FETCHING';
const REVIEWS_FETCED='REVIEWS_FETCED';
const REVIEWS_FETCH_FAILED='REVIEWS_FETCH_FAILED';

class ReviewDetails extends Component {
    state={
product:null,
review:null,
error:null
    };
    render() {
        const {status,error,review,product}=this.state;
    let el=null;
    switch(status){
        case REVIEWS_FETCHING:
            el=(
            <Alert type="info"><strong>Hang on! REviews are been fetched</strong></Alert>)
    
        break;
        case REVIEWS_FETCED:
            el=(
                <div className="row">
                    {

review.map(review=>(

             <div className="col-4 my-3" to={`/catalog/product.id/{reviews}`}>
                <div class="card">
                   
                    <div class="card-body">
               
                        {/* <h4 class="card-title">{product.name}</h4>
                        <p class="card-text">{product.price}</p> */}
                        <p>{review.createdDate}</p>
                     <p>reviewer:{review.reviewer}</p>
                     <p>ProductId :{review.productId}</p>
                   
                     <p>Rating: {review.startRating}</p>
                     <p>TITLE: {review.title}</p>
                     <p>Text:{review.text}</p>
                    </div>
                </div>
                </div>
            ))
                    }
                    </div>
            );
            break;
           
        
    
            case REVIEWS_FETCH_FAILED:
              
                el=(<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">Close</span>
                    </button>
                    <strong>Ooops ! we are unable to fetch the data
                        <br/>
                        {error.message}
                    </strong>
                </div>)
                break;
                default:
                    el=null;
                    break;

    }
        return (
            <div>
                <h1>REVIEW</h1>
                <hr/>
                {el}
            </div>
        );
    }
//cdm
componentDidMount() {
    this.setState(
        {
            status:REVIEWS_FETCHING
        }
    );
    CatalogService.getReviews(this.props.match.params.id)
    .then((review)=>
    {
this.setState({review:review,
status:REVIEWS_FETCED})
    })
    .catch((error)=>
    {
        this.setState({
            error:error,
            
            review:null,
            status:REVIEWS_FETCH_FAILED
        })
    })
}

}

export default ReviewDetails;
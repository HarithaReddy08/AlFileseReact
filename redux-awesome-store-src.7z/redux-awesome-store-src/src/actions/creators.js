import{
    CATALOG_FETCHING,
    CATALOG_FETCHED,
    CATALOG_FETCH_FAILED
} from './constants';
function fetchCatalog()
{
    return {
        type: CATALOG_FETCHING
    };
}
function fetchedCatalog(products)
{
    return{
        type:CATALOG_FETCHED,
        payload:
        {
            products
        }
    };
}
    function fetchCatalogFailed(error)
    {
        return{
            type:CATALOG_FETCH_FAILED,
            payload:
            {
                error
            }
        };
    }
    export {
        fetchCatalog,fetchedCatalog,fetchCatalogFailed
    }

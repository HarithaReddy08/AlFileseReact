//rcc
import React, { Component } from 'react';
import CatalogService from '../Services/Catalog';
import Alert from '../components/Alert';
import {Link} from 'react-router-dom';
import{
    CATALOG_FETCHING,
    CATALOG_FETCHED,
    CATALOG_FETCH_FAILED
} from '../actions/constants';
//not needed for redux , only for react
// const CATALOG_FETCHING='CATALOG_FETCHING';
// const CATALOG_FETCHED='CATALOG_FETCHED';
// const CATALOG_FETCH_FAILED='CATALOG_FETCH_FAILED';


class Catalog extends Component {
    state={
products:null,
error:null
    };
    render() {
        const {status,error,products}=this.props;// for redux
        // const {status,error,products}=this.state; // for react
    let el=null;
    switch(status){
        case CATALOG_FETCHING:
            el=(
            <Alert type="info"><strong>Hang on! Products are been fetched</strong></Alert>)
    
        break;
        case CATALOG_FETCHED:
            el=(
                <div className="row">
                    {

products.map(product=>(

             <Link className="col-4 my-3" to={`/catalog/${product.id}`}>
                <div class="card">
                    <img class="card-img-top" src={product.imageUrl} alt=""/>
                    <div class="card-body">
                        <h4 class="card-title">{product.name}</h4>
                        <p class="card-text">{product.price}</p>
                    </div>
                </div>
                </Link>
            ))
                    }
                </div>
    
            );
            break;
            case CATALOG_FETCH_FAILED:
                el=(<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">Close</span>
                    </button>
                    <strong>Ooops ! we are unable to fetch the data
                        <br/>
                        {error.message}
                    </strong>
                </div>)
                break;
                default:
                    el=null;
                    break;

    }
        return (
            <div>
                <h1>CATALOG</h1>
                <hr/>
                {el}
            </div>
        );
    }
//cdm
componentDidMount() {
    this.props.fetchCatalog();

    // this.setState( //for react
    //     {
    //         status:CATALOG_FETCHING
    //     }
    // );
    CatalogService.getProducts()
    .then((products)=>
    {
        this.props.fetchedCatalog(products)
// this.setState({products:products,  //for react
// status:CATALOG_FETCHED})
    })
    .catch((error)=>
    {
        this.props.fetchCatalogFailed(error);
        // this.setState({ //for react
        //     error:error,
        //     products:null,
        //     status:CATALOG_FETCH_FAILED
        // })
    })
}

}

export default Catalog;
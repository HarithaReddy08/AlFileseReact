import React from 'react';

function Alert({type,children})
{
    return(
        <div>
<div class={`alert alert-${type} alert-dismissible fade show`} role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                <span class="sr-only">Close</span>
            </button>
            {children}
        </div>
        </div>);
}
export default Alert
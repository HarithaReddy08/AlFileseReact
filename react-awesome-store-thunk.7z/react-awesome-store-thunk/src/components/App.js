import React from 'react';
import Home from './Home';
import {Route} from 'react-router-dom';
import Navbar from './Navbar';
import Review from '../components/Review';
import Catalog from '../containers/Catalog';
// import Catalog from './Catalog'; //for react 
import ProductDetails from './ProductDetails';
function App(props)
{
    return(
        <div>
         <Navbar/>

       <div className="container my-4">
           <Route path="/"exact component={Home}/>
           <Route path="/catalog" exact component={Catalog}/>
           <Route path="/catalog/:id"  component={ProductDetails}/>
           <Route path="/catalog/:id/reviews" component={Review}/>
           {/* <Route path="/product/id" */}
     </div>
        </div>
    );
}
export default App;
import axios from 'axios';
import Catalog from '../components/Catalog';
export default class CatalogService{
   static baseUrl='https://awesome-store-server.herokuapp.com'
    static getProducts()
    {
// axios.*() returns a promise object (promise is built-in class in JS - it was introduced in ES2015)
// then() AND catch() ARE 2 methods of promise object
      return  axios.get(`${this.baseUrl}/products`)
        .then(function(response) // when backend succesfully returns the data
        {
return response.data; //data returned by backend(array of products)
        })
        .catch(function(error){ //when backend was not able to return the data
console.log(error.message);
throw error;
        })
    }
    static getReviews(id)
    {

      return  axios.get(`${this.baseUrl}/products/${id}/reviews`)
        .then(function(response) 
        {
return response.data; 
        })
        .catch(function(error){
console.log(error.message);
throw error;
        })
    }
    static addReview(review,id){
        review.producId=parseInt(id);
        return  axios.post(`${this.baseUrl}/reviews`,review,
        {
            headers:{'Content-Type':'application/json'}})
        .then(function(response) 
        {
return response.data; 
        })
        .catch(function(error){
console.log(error.message);
throw error;
    });
}
       
}

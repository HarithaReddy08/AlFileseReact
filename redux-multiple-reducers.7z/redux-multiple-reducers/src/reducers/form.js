/* Define and export the form reducer that hanldes UPDATE_NAME action */
import {UPDATE_NAME} from '../actions/constants';
export default function formReducer(CurState={name:''},action)
{
    let newState;
    switch(action.type)
    {
        case UPDATE_NAME:
            newState={...CurState,name:action.payload.name};
            break;
            default:
                newState=CurState;
    }
    return newState;
}
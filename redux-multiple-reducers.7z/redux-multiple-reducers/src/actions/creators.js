import { INCREMENT, DECREMENT,UPDATE_NAME } from './constants';

function incrementAC() {
    return {
        type: INCREMENT
    };
} 

function decrementAC() {
    return {
        type: DECREMENT
    };
}
function UpdateNameAC(name)
{
    return{
        type:UPDATE_NAME,
        payload:
        {
            name:name
        }
    };
}
// add action creator for UPDATE_NAME and export it - it takes name as a parameter and sets up on the action's payload

export {
    incrementAC,
    decrementAC,
    UpdateNameAC
};
const CATALOG_FETCHING='CATALOG_FETCHING';
const CATALOG_FETCHED='CATALOG_FETCHED';
const CATALOG_FETCH_FAILED='CATALOG_FETCH_FAILED';
export{
    CATALOG_FETCHING,
    CATALOG_FETCHED,
    CATALOG_FETCH_FAILED
}                                                                       
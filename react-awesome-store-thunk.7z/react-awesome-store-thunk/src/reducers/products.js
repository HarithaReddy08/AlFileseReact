import{
    CATALOG_FETCHING,
    CATALOG_FETCHED,
    CATALOG_FETCH_FAILED
} from '../actions/constants';
export default function(curState={products:null, status:'',error:null},action)
{
    let newState;
    switch(action.type)
    {
        case CATALOG_FETCHING:
    newState={...curState,status:CATALOG_FETCHING};
        break;
        case CATALOG_FETCHED:
            newState={...curState,status:CATALOG_FETCHED,products:action.payload.products};
        break;
        case CATALOG_FETCH_FAILED:
            newState={...curState,status:CATALOG_FETCH_FAILED,error:action.payload.error};
        break;
       
        default:
            newState=curState;
    }
return newState;
}
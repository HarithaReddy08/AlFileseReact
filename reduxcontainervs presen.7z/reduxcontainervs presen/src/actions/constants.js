// action types
const INCREMENT = 'INCREMENT';
const DECREMENT = 'DECREMENT';

const UPDATE_NAME = 'UPDATE_NAME';

export {
    INCREMENT,
    DECREMENT,
    UPDATE_NAME
};
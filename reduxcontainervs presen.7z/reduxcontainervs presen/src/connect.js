import React from 'react';
import store from './store';

// Define a Higher Order Component HOC called connect()
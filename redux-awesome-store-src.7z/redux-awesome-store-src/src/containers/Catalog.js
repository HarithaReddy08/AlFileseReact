import Catalog from '../components/Catalog';
import {connect} from 'react-redux';
import{
  fetchCatalog,fetchedCatalog,fetchCatalogFailed
} from '../actions/creators';
const mapStateToProps=(state)=>{
    return{
  ...state.productState
    };
}
const mapDispatchToProps=(dispatch)=>
{
    return{
  fetchCatalog()
  {
      dispatch(fetchCatalog());
  },
  fetchedCatalog(products)
  {
      dispatch(fetchedCatalog(products));
  },
  fetchingCatalogFailed(error)
  {
      dispatch(fetchCatalogFailed(error));
  }
};
}
export default connect(mapStateToProps,mapDispatchToProps)(Catalog);
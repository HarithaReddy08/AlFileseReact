import { createStore, combineReducers,applyMiddleware } from 'redux';
//import middle ware for thunk
import products from './reducers/products';
import thunk from 'redux-thunk';



export default createStore( 
    // use combineReducers() to generate a master reducer tha that delegates to counter and form reducers
    combineReducers(
        {
            productState: products,
          
        }
    ),
    applyMiddleware(thunk)
);
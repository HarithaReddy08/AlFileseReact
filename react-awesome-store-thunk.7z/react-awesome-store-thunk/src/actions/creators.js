import{
    CATALOG_FETCHING,
    CATALOG_FETCHED,
    CATALOG_FETCH_FAILED
} from './constants';
import catalogService from '../Services/Catalog';
function fetchCatalog()
{
    return {
        type: CATALOG_FETCHING
    };
}
function fetchedCatalog(products)
{
    return{
        type:CATALOG_FETCHED,
        payload:
        {
            products
        }
    };
}
    function fetchCatalogFailed(error)
    {
        return{
            type:CATALOG_FETCH_FAILED,
            payload:
            {
                error
            }
        };
    }
    //for thunk
    function fetchCatalogThunk(dispatch)
    {
        dispatch(fetchCatalog());
        catalogService.getProducts()
        .then((products)=>
        {
            dispatch(fetchedCatalog(products));
        })
        .catch((error)=>{
            dispatch(fetchCatalogFailed(error));
        });
    }
    export {
        fetchCatalog,fetchedCatalog,fetchCatalogFailed,fetchCatalogThunk
    }

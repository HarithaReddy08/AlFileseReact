// Use connect() to define the connected component (aka container component) for Counter. Define mapDispatchToProps() and mapStateToProps() to be passed to connect().
import {connect} from 'react-redux';
import Counter from '../components/Counter';
import { incrementAC, decrementAC } from '../actions/creators';
const mapStateToProps=(state)=>{
    return{
        counter:state.counterState.value
    }
}
const mapDispatchToProps=(dispatch)=>
{
    return{
    increment()
    {
dispatch(incrementAC());
    },
    decrement()
    {
        dispatch(decrementAC());
    }
}
}
export default connect(mapStateToProps,mapDispatchToProps)(Counter);
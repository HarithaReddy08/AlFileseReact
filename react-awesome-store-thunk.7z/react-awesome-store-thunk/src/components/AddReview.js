import React, { Component } from 'react';
import CatalogService from '../Services/Catalog';

class AddReview extends Component {
  //for validation create a state
  state={
    value: {reviewer:'',
    starRating:'',
    text:'',
    title:''},
    errors:
    {
      reviewer:[],
      starRating:[],
      text:[],
      title:[]},
      wasValidated:false  
  };

    reviewerRef=React.createRef();
    starRatingRef=React.createRef();
    titleRef=React.createRef();
    textRef=React.createRef();
    AddReview=(ev)=>
    {
        //stops frm submission by browser
        //instead we will 
ev.preventDefault();
// const review={
//     reviewer:this.reviewerRef.current.value,
//     starRating:parseInt(this.starRatingRef.current.value),
//     title:this.titleRef.current.value,
//     text:this.textRef.current.value
    
// }
const review=this.state.values;

CatalogService.addReview(review, this.props.match.params.id)}//.then(function(updatedReview)
// {
//     alert(`your review was successfully posted`);
//     // this.props.history.push('')
// })
//     .catch(function()
//     {
// alert('there was a problem posting your review');
//     })

   // }
   //for validation
update=(event)=>
{
  console.log(event);
  // event.target.value
  // event.target.name
  const newValues={
 ...this.state.values,
 [event.target.name]:event.target.value
  }
  this.setState(curState=>({...curState,


  values:newValues
  
}),
this.validate
);


}
   validate=()=>
   {
     const errors={
       reviewer:[],
       starRating:[],
       text:[],
       title:[]
     }
     //check reviewer input for errors and add error messages
if(this.reviewerRef.current.value==='')
{
errors.reviewer.push('Your name is erquired');
}
if(this.starRatingRef.current.value==='')
{
errors.reviewer.push('Rating between 1-5');
}
if(this.titleRef.current.value.length<3|| this.titleRef.current.value.length>20)

{
errors.title.push('title must be atleast 20 characters');
}
if(this.textRef.current.value.length<20)
{
errors.text.push('review must have atleast 20 characters');
}
this.setState({
  ...this.state,
  errors:errors,
  wasValidated:true
});
   }
   isValid=()=>
   {
     const {reviewer,starRating,title, text}=this.state.errors;
     return reviewer.length===0 && starRating.length===0 && title.length===0 && text.length===0
   }
    render() {
        return (
            <div>
                <h2>Add a  REview</h2>
                <hr/>
                <form className={`form-horizontal ${this.state.wasValidated? 'was-validated':''}`} onSubmit={this.AddReview} noValidate>
<div class="form-group">
  <label for="reviewer">Your Name</label>
  <input type="text" name="reviewer" id="reviewer" class={`form-control ${this.state.errors.reviewer.length===0? `is-valid`:`is-invalid`}`} placeholder="" aria-describedby="reviewerHelp" ref={this.reviewerRef} onChange={this.update}/>
  <small id="helpId" class="text-muted">Please enter the full name</small>
  <div className="invalid-feedback">
  
  {
    this.state.errors.reviewer.map(error=><div>{error}</div>)
  }
  </div>
</div>
<div class="form-group">-
  <label for="starRating">Star Rating</label>
  <select  name="starRating" id="starRating" class={`form-control ${this.state.errors.starRating.length===0? `is-valid`:`is-invalid`}`} placeholder="" aria-describedby="starRatingHelp" ref={this.starRatingRef} onChange={this.update}>
      <option></option>
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4
      </option>
      <option>5</option>
      </select>
  <small id="startingHelp" class="text-muted">Please choose rating from 1-5</small>
  <div className="invalid-feedback"></div>
  {
    this.state.errors.starRating.map(error=><div>{error}</div>)
  }
</div>
<div class="form-group">
  <label for="title">title</label>
  <input type="text" name="title" id="title" class={`form-control ${this.state.errors.title.length===0? `is-valid`:`is-invalid`}`} placeholder="" aria-describedby="titleHelp" ref={this.titleRef} onChange={this.update}/>
  <small id="titleHelp" class="text-muted">Please title for your Review </small>
  <div className="invalid-feedback"></div>
  {
    this.state.errors.title.map(error=><div>{error}</div>)
  }
</div>
<div class="form-group">
  <label for="text">your Review</label>
  <textarea type="text" name="text" id="text" class={`form-control ${this.state.errors.text.length===0? `is-valid`:`is-invalid`}`} placeholder="" aria-describedby="textHelp" ref={this.textRef} onChange={this.update}></textarea>
  <small id="textHelp" class="text-muted">Please enter your REview</small>
  <div className="invalid-feedback"></div>
  {
    this.state.errors.text.map(error=><div>{error}</div>)
  }
</div>


<div>
    <button className="btn btn-sm btn-primary" disabled={!this.isValid()}>SUBMIT</button>
</div>

                </form>
            </div>
        );
    }
}

export default AddReview;
//rcc
import React, { Component } from 'react';
import Review from '../components/Review';
import DetailsService from '../Services/Details';
import Alert from '../components/Alert';
import AddReview from './AddReview';
import { Route, Link } from 'react-router-dom';
const DETAILS_FETCHING='DETAILS_FETCHING';
const DETAILS_FETCHED='DETAILS_FETCHED';
const DETAILS_FETCH_FAILED='DETAILS_FETCH_FAILED';


class ProductDetails extends Component {
    state={
product:null,
error:null
    };
    render() {
        const {status,error,product}=this.state;
    let el=null;
    switch(status){
        case DETAILS_FETCHING:
            el=(
            <Alert type="info"><strong>Hang on! Products are been fetched</strong></Alert>)
    
        break;
        case DETAILS_FETCHED:
            el=(
                <div className="row">
                 <div className="col-4">
                     <img src={product.imageUrl} className="img-fluid"/>
                 </div>
               
                 <div className="col-8">
                 <h2>{product.name}</h2>
                 <hr/>
                     <p>{product.description}</p>
                     <p>code:${product.code}</p>
                     <p>Realesd on :{product.releaseDate}</p>
                     <p>Price: {product.price}</p>
                     <p>Rating: {product.startRating}</p>
                 </div>
                    
                    </div>
            );
            break;
            case DETAILS_FETCH_FAILED:
              
                el=(<div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">Close</span>
                    </button>
                    <strong>Ooops ! we are unable to fetch the data
                        <br/>
                        {error.message}
                    </strong>
                </div>)
                break;
                default:
                    el=null;
                    break;

    }
        return (
            <div>
               
                {el}
                <Link to={this.props.match.url}>Review</Link>{''}
                <Link to={`${this.props.match.url}/add`}>AddReview</Link>
                <Route path={this.props.match.path} exact component=
                {Review}/>
                 <Route path={`${this.props.match.path}/add`} component={AddReview}/>
                     </div>
               // {Review}/>
                // <AddReview />
                // <Review id={this.props.match.params.id}/>
        
        );
    }
//cdm
componentDidMount() {
    this.setState(
        {
            status:DETAILS_FETCHING
        }
    );
    DetailsService.getProduct(this.props.match.params.id)
    .then((product)=>
    {
this.setState({product:product,
status:DETAILS_FETCHED})
    })
    .catch((error)=>
    {
        this.setState({
            error:error,
            product:null,
            status:DETAILS_FETCH_FAILED
        })
    })
}

}

export default ProductDetails;
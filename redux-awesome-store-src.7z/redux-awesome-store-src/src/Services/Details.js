import axios from 'axios';
export default class DetailsService{
    static baseUrl='https://awesome-store-server.herokuapp.com'
     
     static getProduct(id)
     {

       return  axios.get(`${this.baseUrl}/products/${id}`)
         .then(function(response)
         {
 return response.data; 
         })
         .catch(function(error){ 
 console.log(error.message);
 throw error;
         })
     }
 }
 
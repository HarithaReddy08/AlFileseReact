// Modify this to a presentation component (it is ideally a function component) - the evnt handlers will dispatch via appropriate props, and state will be available in props

import React from 'react';

import store from '../store';

export default function Counter(props) {
// export default class Counter extends React.Component {
    // constructor( props ) {
    //     super( props );
    // }

    // increment = () => {
    //     store.dispatch( incrementAC() );
    // }

    // decrement = () => {
    //     store.dispatch( decrementAC() );
    // }

        return (
            <div>
                <span>{props.counter}</span>
                <button onClick={props.increment}>+</button>
                <button onClick={props.decrement}>-</button>
            </div>
        );
    
//no need
    // componentDidMount() {
    //     store.subscribe( this.forceUpdate.bind( this ) );
    // }
}